import{default as t}from"../components/error.svelte-2c9ed51b.js";export{t as component};
