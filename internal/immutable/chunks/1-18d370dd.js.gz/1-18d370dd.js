import{default as t}from"../components/error.svelte-9c7ed6fd.js";export{t as component};
